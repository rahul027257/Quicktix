# QuickTix: event ticket booking platform

A complete, working ticket-booking website for concerts, sports, movies, comedy, workshops, conferences,
festivals, exhibitions and college events.

* **Stack:** Python 3.10+, Flask, SQLite (WAL), Jinja templates, plain CSS/JS (no build step).
* **Highlights:** safe 10-minute ticket holds that are released if the customer walks away, UPI payments verified by the
  organizer before any ticket exists, a clearly labelled **demo** payment provider behind a swappable
  interface, one unique QR code per individual ticket, PDF tickets, organizer QR verification with atomic
  "admit once" check-in, and a test suite that includes real multi-connection concurrency tests.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt                       # runtime + test dependencies

python manage.py init-db                                  # create tables + default categories
python manage.py seed                                     # realistic sample data (prints demo logins)
python manage.py create-admin                             # secure admin setup (password prompt)
python manage.py run                                      # http://127.0.0.1:5000
```

`seed` is optional; without it you start with an empty marketplace and can register users and create events
yourself. `python manage.py seed --reset` wipes users/events/bookings and reloads the sample data.

### Demo logins (created by `seed`)

| Role                    | Email                       | Password        |
|-------------------------|-----------------------------|-----------------|
| Customer                | customer@quicktix.demo      | Customer123!    |
| Organizer               | organizer@quicktix.demo     | Organizer123!   |
| Organizer (second)      | organizer2@quicktix.demo    | Organizer123!   |
| Customer with a pending organizer request | aspiring@quicktix.demo | Aspiring123! |

**There is no default admin.** Create it with `python manage.py create-admin` (it asks for a name, email and a
password of 12+ characters; for scripted setups set `QUICKTIX_ADMIN_EMAIL` / `QUICKTIX_ADMIN_PASSWORD`).
Public registration can only ever create customers, and the web UI cannot promote anyone to admin.

### Try the interesting flows

1. Log in as the customer, open *Neon Harbour*, hold tickets, and watch the countdown on the checkout page.
2. Click **Pay (demo)**: the simulated payment page lets you choose *approve*, *decline*, *leave processing* or *cancel*.
3. Open **My tickets**: each seat has its own QR code, a ticket page, and a PDF.
4. In a second browser, log in as the organizer, open **Scan tickets** and paste the ticket link (or scan the QR with the
   camera on HTTPS/localhost). Admit it, then try again to see **Already used**.
5. As admin, approve *Alex Aspiring*'s organizer request, review ticket usage, and view the inventory health check.

## Configuration

Plain environment variables (see `.env.example`). The most useful ones:

| Variable | Default | Purpose |
|---|---|---|
| `QUICKTIX_SECRET_KEY` | generated into `instance/secret_key` | Session signing key. **Set explicitly in production.** |
| `QUICKTIX_BASE_URL` | URL of the request | Public origin placed inside QR codes, e.g. `https://tickets.example.com`. |
| `QUICKTIX_DATABASE` | `instance/quicktix.db` | SQLite file. |
| `QUICKTIX_RESERVATION_MINUTES` | `10` | Length of the ticket hold. |
| `QUICKTIX_CURRENCY_SYMBOL` / `_CODE` | `₹` / `INR` | Display currency (amounts are stored as integer cents). UPI needs INR. |
| `QUICKTIX_DEMO_PAYMENTS` | `1` | Offer the simulated payment page to organizers who haven't set up UPI. |
| `QUICKTIX_UPI_VERIFY_HOURS` | `48` | How long seats stay held while an organizer verifies a UPI payment. |
| `QUICKTIX_ABANDON_AFTER_SECONDS` | `180` | Release a checkout nobody has had open this long (no payment sent). |
| `QUICKTIX_TIMEZONE` | `UTC` | Timezone in which event wall-clock times are entered and compared. |
| `QUICKTIX_COOKIE_SECURE` | `0` | Set `1` behind HTTPS. |
| `QUICKTIX_CANCELLATION_CUTOFF_HOURS` | `24` | Customers can cancel up to N hours before an event. |
| `QUICKTIX_WEBHOOK_SECRET` | dev value | HMAC secret for payment webhooks. |

## How the important parts work

### Inventory and temporary reservations (`services/reservations.py`)

`events.available_tickets` is the live count shown to everyone, and the invariant
**capacity = available + held (active reservations) + sold (confirmed bookings)** always holds.

* Holding tickets is one conditional statement:
  `UPDATE events SET available_tickets = available_tickets - :qty WHERE id = :id AND status = 'published' AND available_tickets >= :qty`.
  If it touches no row, there weren't enough tickets, so overselling is impossible regardless of how many requests race.
* A reservation moves through a strict state machine, each step a guarded `UPDATE ... WHERE status = 'active'`:
  `active -> confirmed | cancelled | expired | failed`. Only the request whose update changes a row may return tickets
  to stock, which is why inventory is restored **exactly once**. A `CHECK (available_tickets <= capacity)` constraint
  is a last line of defence.
* Every write path runs in `BEGIN IMMEDIATE` transactions (`db.transaction`, nestable via savepoints).
* Expiry works with the browser closed: a background sweeper thread (every 15 s), `python manage.py expire-reservations`
  (for cron/systemd), and a cheap lazy sweep before every availability-sensitive request.
* One live hold per customer per event (partial unique index) plus a per-form request token make double clicks harmless.

### Abandoned checkouts

The checkout page sends a small heartbeat every 15 seconds. If it stops (tab closed, browser closed, customer navigated away)
and no payment has been sent, the held tickets are released after `QUICKTIX_ABANDON_AFTER_SECONDS` (default 180). A payment
in flight, or UPI details already submitted, is never treated as abandoned. The 10-minute hold limit still applies on top.
Released checkouts stay in the customer's **Expired** tab for history.

### UPI payments to the organizer (`services/upi.py`, `payments/upi.py`)

1. **Each event can have its own UPI ID and/or payment QR:** set them in the event's Create/Edit form under *How customers pay you for this event*
   (organizers see this section; admins don't). Or save **default details** once under *Default payment details* and let events use those.
   An event with its own details always uses them; otherwise it falls back to the organizer's defaults.
2. The customer books, pays that UPI ID (the checkout shows a QR with the exact amount and reference filled in, plus the
   organizer's own QR), then submits the **transaction ID and a screenshot**.
3. The organizer sees it under **Verify payments**, checks their bank/UPI app and **confirms** or **rejects** (with a reason).
4. **Only confirmation creates the booking and the ticket QR codes.** Until then no ticket rows exist, so there is nothing to scan.
   Rejection releases the seats and the customer sees the reason.

Safeguards: admins can't view or change payment details (so nobody can redirect another organizer's money); a transaction ID can't be submitted twice; screenshots are re-encoded and only visible to the customer, the event's
organizer and admins; only the event's own organizer can confirm; the seats stay held for `QUICKTIX_UPI_VERIFY_HOURS` (48) and
are released if nobody decides; a paid event can't be published unless customers can pay for it. If an organizer has UPI details,
the demo gateway is not offered for their events. Set `QUICKTIX_DEMO_PAYMENTS=0` to switch the demo gateway off everywhere
(free events then use a one-click confirmation). UPI is rupee-only, so the site currency defaults to INR.

### Payments (`payments/`, `services/payments.py`)

Payment code never touches inventory directly. `apply_provider_status` is the **only** place a provider result turns
into a booking or a release, and it is idempotent.

* `PaymentProvider` is a three-method interface (`create_session`, `get_status`, `verify_webhook`).
  `DemoProvider` simulates a hosted payment page and keeps its state in its own table, like a remote provider would.
* A browser redirect is **never** proof of payment: the return URL ignores its query string and asks the provider
  server-to-server. Webhooks are HMAC-signed and are only used to *find* the payment; the status is re-fetched.
* Uncertain ("processing") payments keep the hold alive (bounded by a cap). If money arrives after the hold has been
  released, the payment is marked `refunded` and no booking is created, so seats are never double-sold.
* **To go live:** implement `PaymentProvider` for Stripe/Razorpay/etc. and return it from `payments.get_provider`.
  Nothing else changes.

### Tickets, QR codes and verification (`services/tickets.py`)

* Every seat is its own `tickets` row with a 144-bit random `code` and a readable number (`QT-ABCD2345-T01`).
* The QR encodes `<BASE_URL>/verify/<code>`: an opaque token, no personal data.
* Staff open that URL (or use the in-browser camera scanner, which bundles jsQR and uses `BarcodeDetector` when
  available). Results: **Valid, Invalid, Cancelled, Already used**. Organizers can verify only their own events; admins all.
* Admission is `UPDATE tickets SET status='used' WHERE code=? AND status='valid'`: when twenty scanners hit the same ticket,
  exactly one is admitted. Cancelling a booking cancels all of its tickets. Every scan is logged for admin review.
* PDFs (ReportLab) are generated from database rows, one page per ticket, owner/admin only, refused for cancelled bookings.

### Security

Hashed passwords (Werkzeug scrypt), CSRF tokens on every POST, HttpOnly + SameSite session cookies, session reset on login,
login throttling, server-side role checks on every protected route, ownership enforced inside SQL queries (other people's
bookings and tickets return 404), parameterised SQL everywhere, escaped templates, a strict Content-Security-Policy
(no inline scripts or styles), safe redirects, re-encoded image uploads, disabled users logged out on their next request.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest
```

176 tests, about 15 seconds. They cover registration/login/roles, event management and ownership, organizer approval, discovery
filters/sorting, reservations, **two customers competing for the last two tickets** (sequential and truly concurrent),
cancel/expire restoring inventory exactly once, successful payment confirming exactly once, duplicate/replayed requests,
payment failure/cancel/uncertain/late outcomes, webhook signatures, per-ticket QR generation (decoded with a real QR reader),
scan/verify/admit, double-admission under 20 concurrent scanners, cancelled-booking invalidation, PDF downloads, cross-customer
access attempts and hostile inputs. The QR-decoding tests need `zxing-cpp` (in `requirements-dev.txt`) and skip without it.

## Project layout

```
manage.py                     CLI: init-db, seed, create-admin, expire-reservations, run
quicktix/
  schema.sql, db.py           tables, constraints, transaction helper
  services/                   all business rules (framework-free): reservations, bookings, payments, tickets, events, users, catalog
  payments/                   provider interface + demo provider
  views/                      Flask blueprints (public, auth, customer, checkout, tickets, verify, organizer, admin)
  templates/, static/         UI (self-hosted font and scripts; no external requests)
  seed.py, cli.py             sample data and commands
tests/                        service-level, concurrency and web-level tests
tools/make_posters.py         regenerates the sample-event artwork (SVG)
```

## Production notes

* Serve behind HTTPS with a real WSGI server: `gunicorn -w 4 "quicktix:create_app()"`. Set `QUICKTIX_SECRET_KEY`,
  `QUICKTIX_BASE_URL` and `QUICKTIX_COOKIE_SECURE=1`. Browsers only allow the camera scanner on HTTPS or localhost.
* SQLite in WAL mode handles many concurrent readers and serialised writers on a single machine. For multiple app servers,
  move to PostgreSQL: the conditional-`UPDATE` inventory pattern and state-machine guards are standard SQL and rely on
  row locks there (replace `BEGIN IMMEDIATE` with a normal transaction, and port the two partial indexes, which PostgreSQL supports).
* The login throttle is per process (in memory); use a shared store or a reverse-proxy limiter if you run several workers.
* Every worker starts its own sweeper; this is safe because releases are guarded transitions.
* Payments are a simulator. No card data is ever collected.
